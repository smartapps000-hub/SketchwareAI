Important:

I've added contents of /libs/repackaged.jar into /classes.jar so that those classes
get compiled with Sketchware Pro's build system too. Make sure to do that too if you're
upgrading the library!

 - Jbk0
 
